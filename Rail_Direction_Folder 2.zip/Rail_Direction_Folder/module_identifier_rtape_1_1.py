import numpy as np
import cv2
def main():
    img = cv2.imread("C1.jpeg",1)
    return img_raw

#Splitting the image into RGB bands.
def filter_green(img_raw):
    green = img_raw[:,:,1]
    return filtered_image


#Binary thresholding the green band.
def threshold_image(filtered_image):
    ret,thresh1 = cv2.threshold(final_image,100,255,cv2.THRESH_BINARY)
    return final_image

#Finding the height, width and channels of the image and printing them.

def hwc_img(img_raw):
    height, width, channels = img.shape #Super important to know for our program!!
    return hwc



#print(green)
#cv2.imshow('blue',blue)
#cv2.imshow('green',green)
#cv2.imshow('red',red)

#Displays the thresholded image as black and white.
def show_final():
    cv2.imshow('threshold',final_image)

#Closes program
cv2.waitKey(0)
cv2.destroyAllWindows()

def load_image():
    return thresh1

if __name__ == "__main__":
    main()

