import numpy as np
import cv2
img = cv2.imread("B5.jpeg",1)
cv2.imshow('image',img)


red = img[:,:,0] 
green = img[:,:,1]
blue = img[:,:,2] 

height, width, channels = img.shape #Super important to know for our program!!
print height, width, channels


#print(green)
cv2.imshow('blue',blue)
cv2.imshow('green',green)
cv2.imshow('red',red)

cv2.imwrite('B5_Green.jpeg',green)

cv2.waitKey(0)
cv2.destroyAllWindows()





###Mat img = imread("image.jpg");
#Mat grey;
#cvtColor(img, grey, CV_BGR2GRAY);

#Mat sobelx;
#Sobel(grey, sobelx, CV_32F, 1, 0);

#double minVal, maxVal;
#minMaxLoc(sobelx, &minVal, &maxVal); //find minimum and maximum intensities
#Mat draw;
#sobelx.convertTo(draw, CV_8U, 255.0/(maxVal - minVal), -minVal * 255.0/(maxVal - minVal));

#namedWindow("image", CV_WINDOW_AUTOSIZE);
#imshow("image", draw);
#waitKey();
