import numpy as np
import cv2
from matplotlib import pyplot as plt
img = cv2.imread("B5.jpeg",1)
cv2.imshow('image',img)


red = img[:,:,0] 
green = img[:,:,1]
blue = img[:,:,2]

ret,thresh1 = cv2.threshold(green,100,255,cv2.THRESH_BINARY)
height, width, channels = img.shape #Super important to know for our program!!
print height, width, channels


#print(green)
#cv2.imshow('blue',blue)
#cv2.imshow('green',green)
#cv2.imshow('red',red)
cv2.imshow('threshold_B5',thresh1)

cv2.waitKey(0)
cv2.destroyAllWindows()


