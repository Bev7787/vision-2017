#Function 'Module Identifier Rtape
#This code takes an image, seperates the green band and binary thresholds
#the green band.
#The binary threshold keeps all green values above 100 while turning all green
#values below 99 off.
#The output is a black image with two white rectangles in the center of the image.
#21st January 2017
#Author: Bevan Tsui


#Loading required modules and image.
import numpy as np
import cv2
from matplotlib import pyplot as plt
img = cv2.imread("C1.jpeg",1)
cv2.imshow('image',img)

#Splitting the image into RGB bands.
red = img[:,:,0] 
green = img[:,:,1]
blue = img[:,:,2]
 
#Binary thresholding the green band.
ret,thresh1 = cv2.threshold(green,100,255,cv2.THRESH_BINARY)

#Finding the height, width and channels of the image and printing them.
height, width, channels = img.shape #Super important to know for our program!!
print height, width, channels


#print(green)
#cv2.imshow('blue',blue)
#cv2.imshow('green',green)
#cv2.imshow('red',red)

#Displays the thresholded image as black and white.
cv2.imshow('threshold_B5',thresh1)

#Closes program
cv2.waitKey(0)
cv2.destroyAllWindows()
