
import cv2
import numpy as np


def main():
    image = "xyz"
    print filter_green(image, 100)

    image_2 = "sdf"
    print filter_green(image_2, 120)    


def filter_green(image_name, threshold)
    ...
    return filtered_image

def test_filtered_green()
    assert a == b


if __name__ = "__main__":
    main()
